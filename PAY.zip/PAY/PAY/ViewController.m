//
//  ViewController.m
//  PAY
//
//  Created by Higgses on 16/5/31.
//  Copyright © 2016年 ChanlyTech inc. All rights reserved.
//
#define WIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height

#define ALIPAY_URL @"http://10.6.0.235/pingpp-php-master/test.php?channel=alipay&type=live"
#define BFB_URL    @"http://10.6.0.235/pingpp-php-master/test.php?channel=bfb&type=live"
#define SCHEME     @"alipay"

#import "ViewController.h"
#import "Pingpp.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSArray *array = @[@"支付宝",@"百度钱包"];
    for (int i = 0; i < array.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake((WIDTH - 100) / 2, 100 + 100 * i, 100, 50);
        [self.view addSubview: button];
        [button setTitle:array[i] forState:UIControlStateNormal];
        button.tag = 300 + i;
        [button addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
        button.layer.borderWidth = 1;
        button.layer.borderColor = [UIColor blueColor].CGColor;
    }
    [Pingpp setDebugMode:YES];
}

- (void) action:(UIButton *) sender {
    if (sender.tag == 300) {
        [self requestData:ALIPAY_URL];
        self.view.backgroundColor = [UIColor yellowColor];
    }
    if (sender.tag == 301) {
        [self requestData:BFB_URL];
    }
}

- (void) requestData:(NSString *) url {
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:url] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (!error) {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:1 error:nil];
            [Pingpp createPayment:dict
                   viewController:self
                     appURLScheme:SCHEME
                   withCompletion:^(NSString *result, PingppError *error) {
                       if ([result isEqualToString:@"success"]) {
                           // 支付成功
                       } else {
                           // 支付失败或取消
                           NSLog(@"Error: code=%lu msg=%@", (unsigned long)error.code, [error getMsg]);
                       }
                   }];
        }
        else {
            NSLog(@"%@",error);
        }
    }];
    [dataTask resume];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
