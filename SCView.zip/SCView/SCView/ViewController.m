//
//  ViewController.m
//  SCView
//
//  Created by Higgses on 16/5/23.
//  Copyright © 2016年 ChanlyTech inc. All rights reserved.
//
#define WIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height
#import "ViewController.h"

@interface ViewController ()<UIScrollViewDelegate> {
    UIScrollView *myScrollView;
    NSTimer *timer;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    myScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 100, self.view.bounds.size.width, 200)];
    myScrollView.backgroundColor = [UIColor magentaColor];
    [self.view addSubview:myScrollView];
   // self.view.backgroundColor = [[UIColor alloc] initWithRed:100 / 255.0 green:100 / 255.0 blue:200 / 255.0 alpha:1];
    myScrollView.pagingEnabled = YES;
    myScrollView.bounces = NO;
    myScrollView.showsVerticalScrollIndicator = NO;
    myScrollView.showsHorizontalScrollIndicator = NO;
    
    for (int i = 0; i < 7; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * WIDTH, 0, WIDTH, myScrollView.frame.size.height)];
        imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"0%d.jpg",i]];
        [myScrollView addSubview:imageView];
    }
    timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(changeImage) userInfo:nil repeats:YES];
    myScrollView.contentSize = CGSizeMake(WIDTH * 7, myScrollView.bounds.size.height);
}

- (void)dealloc {
    if (timer) {
        [timer invalidate];
        timer = nil;
    }
}

- (void) changeImage {
    static int currentIndex = 0;
    currentIndex = (currentIndex + 1) % 7;
  //  NSLog(@"%d",currentIndex);
    CGPoint offset = myScrollView.contentOffset;
    offset.x = WIDTH * currentIndex;
    // 带动画效果改变滚动视图的偏移量
    if (currentIndex == 6) {
        myScrollView.contentOffset = offset;
    }
    else {
        [UIView animateWithDuration:0.5 animations:^{
            myScrollView.contentOffset = offset;
        }];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
