//
//  BaseViewController.h
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController


// 设置导航项上的title
- (void)addNavigationItemTitle:(NSString *) title;

// 设置导航项上的UIBarButtonItem
- (void)addBarButtonItemWithTarget:(id)target action:(SEL)selector name:(NSString *) name isLeft:(BOOL) isLeft;
@end
