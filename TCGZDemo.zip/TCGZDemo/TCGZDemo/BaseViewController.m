//
//  BaseViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addNavigationItemTitle:(NSString *)title
{
	UILabel * titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
	titleLabel.font = [UIFont systemFontOfSize:20];
	// #FF00FF
	titleLabel.textColor = [UIColor whiteColor];
	titleLabel.textAlignment = NSTextAlignmentCenter;
	titleLabel.text = title;
	// 设置UINavigationItem的titleView
	self.navigationItem.titleView = titleLabel;
}

- (void)addBarButtonItemWithTarget:(id)target action:(SEL)selector name:(NSString *)name isLeft:(BOOL)isLeft
{
	UIButton * button = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 30)];
	[button setBackgroundImage:[UIImage imageNamed:@"buttonbar_action"] forState:UIControlStateNormal];
	[button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	[button setTitle:name forState:UIControlStateNormal];
	button.titleLabel.font = [UIFont systemFontOfSize:16];
	[button addTarget:target action:selector forControlEvents:UIControlEventTouchDown];
	UIBarButtonItem * buttonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
	
	// 判断是否为左侧按钮
	if (isLeft) {
		self.navigationItem.leftBarButtonItem = buttonItem;
	}
	else {
		self.navigationItem.rightBarButtonItem = buttonItem;
	}
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
