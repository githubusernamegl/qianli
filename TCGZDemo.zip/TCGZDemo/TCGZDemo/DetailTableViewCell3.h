//
//  DetailTableViewCell3.h
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell3 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *i1;
@property (weak, nonatomic) IBOutlet UIImageView *i2;
@property (weak, nonatomic) IBOutlet UIImageView *i3;
@property (weak, nonatomic) IBOutlet UIImageView *i4;
@property (weak, nonatomic) IBOutlet UIImageView *i5;

@property (weak, nonatomic) IBOutlet UIImageView *i6;
@end
