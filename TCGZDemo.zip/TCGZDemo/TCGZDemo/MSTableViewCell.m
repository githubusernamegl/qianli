//
//  MSTableViewCell.m
//  TFGZ
//
//  Created by Higgses on 16/5/6.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import "MSTableViewCell.h"

@implementation MSTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
