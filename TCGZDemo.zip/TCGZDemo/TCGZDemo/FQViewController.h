//
//  FQViewController.h
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListViewController.h"

@interface FQViewController : ListViewController

@end
