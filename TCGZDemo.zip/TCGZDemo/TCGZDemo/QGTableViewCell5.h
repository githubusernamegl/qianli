//
//  QGTableViewCell5.h
//  TFGZ
//
//  Created by Higgses on 16/5/6.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QGTableViewCell5 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *i1;

@end
