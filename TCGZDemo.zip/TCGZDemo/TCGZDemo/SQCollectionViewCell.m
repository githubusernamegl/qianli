//
//  SQCollectionViewCell.m
//  TFGZ
//
//  Created by Higgses on 16/5/9.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import "SQCollectionViewCell.h"

@implementation SQCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
