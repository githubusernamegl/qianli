//
//  QGTableViewCell4.h
//  TFGZ
//
//  Created by Higgses on 16/5/6.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QGTableViewCell4 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *l1;
@property (weak, nonatomic) IBOutlet UILabel *l2;

@end
