//
//  MSViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//
#define WHIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height
#import "MSViewController.h"
#import "MSTableViewCell.h"

@interface MSViewController () <UITableViewDelegate,UITableViewDataSource> {
    UITableView *myTableview;
}

@end

@implementation MSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //self.title = @"";
    self.navigationItem.titleView.hidden = YES;
    [self createTableView];
    [self customNavigationItem];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) createTableView {
    myTableview = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WHIDTH, HEIGHT - 49-49)];
    myTableview.dataSource = self;
    myTableview.delegate = self;
    myTableview.rowHeight = 150;
    myTableview.contentInset = UIEdgeInsetsMake(200, 0, 0, 0);
    myTableview.showsVerticalScrollIndicator = NO;
    
    [myTableview registerNib:[UINib nibWithNibName:@"MSTableViewCell" bundle:nil] forCellReuseIdentifier:@"MSTableViewCell"];
    [self.view addSubview:myTableview];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"msbanner"]];
    imageView.frame = CGRectMake(0, -200, 375, 200);
    [myTableview addSubview:imageView];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (void) customNavigationItem {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 25, 25);
    [button setBackgroundImage:[UIImage imageNamed:@"xia"] forState:UIControlStateNormal];
  //  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, 0, 80, 25);
  //  [button setBackgroundImage:[UIImage imageNamed:@"xia"] forState:UIControlStateNormal];
    [button1 setTitle:@"洛带古镇" forState:UIControlStateNormal];
    
    UIBarButtonItem *button2 = [[UIBarButtonItem alloc] initWithCustomView:button];
    UIBarButtonItem *button3 = [[UIBarButtonItem alloc] initWithCustomView:button1];
    
    self.navigationItem.leftBarButtonItems = @[button2,button3];
}

- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 15;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        MSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MSTableViewCell" forIndexPath:indexPath];
        cell.l1.text = @"政务服务";
        cell.l2.text = @"办事指南";
        cell.l3.text = @"办事预约";
        cell.l4.text = @"进度查询";
        cell.l5.text = @"劳动保障";
        cell.l6.text = @"民生资讯";
        cell.l7.text = @"";
        cell.l7.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if ( indexPath.section == 1) {
        MSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MSTableViewCell" forIndexPath:indexPath];
        cell.l1.text = @"生活服务";
        cell.l2.text = @"天气预报";
        cell.l3.text = @"求职咨询";
        cell.l4.text = @"教育培训";
        cell.l5.text = @"社区服务";
        cell.l6.text = @"出行导航";
        cell.l7.text = @"小镇社区";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else {
        MSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MSTableViewCell" forIndexPath:indexPath];
        cell.l1.text = @"政府管理";
        cell.l2.text = @"社区汇报";
        cell.l3.text = @"签到走访";
        cell.l4.text = @"";
        cell.l5.text = @"";
        cell.l6.text = @"";
        cell.l7.text = @"";
        cell.l4.backgroundColor = [UIColor whiteColor];
        cell.l5.backgroundColor = [UIColor whiteColor];
        cell.l6.backgroundColor = [UIColor whiteColor];
        cell.l7.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
}

@end
