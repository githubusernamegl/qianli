//
//  PseronViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//
#define WHIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height
#import "PseronViewController.h"
#import "FirstTableViewCell.h"

@interface PseronViewController ()<UITableViewDelegate,UITableViewDataSource> {
	UITableView * _tableView;
	NSArray *LabelDataArray;
	NSArray *imageArray;
   // NSTimer *timer;
   // CGFloat  angle;
}

@end

@implementation PseronViewController

//- (void)dealloc {
//    if (timer) {
//        [timer invalidate];
//        timer = nil;
//    }
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
	LabelDataArray =  @[@[@"我的订单",@"我的收藏"],@[@"我的社区",@"我的活动",@"我的游记"],@[@"积分商城",@"意见反馈",@"申请成为商家"]] ;
	imageArray =  @[@[@"dingdan@2x.png",@"shoucang@2x.png"],@[@"shequ@2x.png",@"huodong@2x.png",@"youji@2x.png"],@[@"jifen@2x.png",@"yijian@2x.png",@"shenqing@2x.png"]] ;
	[self createTableView];
    [self customNavigationBar];
   // [self startAnimation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void) customNavigationBar {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 25, 25);
    [button setBackgroundImage:[UIImage imageNamed:@"shezhi"] forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    UIButton *buttonR = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonR.frame = CGRectMake(0, 0, 25, 25);
    [buttonR setBackgroundImage:[UIImage imageNamed:@"xinxi"] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:buttonR];
    
}

- (void)createTableView
{
	_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WHIDTH, HEIGHT - 54-49)];
	[self.view addSubview:_tableView];
	// 设置UITableView的数据源和代理
	_tableView.dataSource = self;
	_tableView.delegate = self;
    _tableView.showsVerticalScrollIndicator = NO;
	
	 _tableView.rowHeight = 50;
	
	// 注册单元格，通过NIB文件注册单元格
	// 参数1：Nib对象
	// 参数2：复用的标识
	[_tableView registerNib:[UINib nibWithNibName:@"FirstTableViewCell" bundle:nil] forCellReuseIdentifier:@"FirstTableViewCell"];
	
	
	_tableView.contentInset = UIEdgeInsetsMake(200, 0, 0, 0);
    UIImageView *imageView =[[UIImageView alloc ]init];
    imageView.frame = CGRectMake(0, -200, WHIDTH, 200);
    imageView.image = [UIImage imageNamed:@"yezi"];
    [_tableView addSubview:imageView];
    UIImageView *smallImage = [[UIImageView alloc] init];
    smallImage.frame = CGRectMake((WHIDTH - 100)/2, 40, 100, 100);
    smallImage.image = [UIImage imageNamed:@"touxiang"];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake((WHIDTH - 60) / 2, 155, 60, 20)];
    smallImage.tag = 300;
    smallImage.layer.cornerRadius = 50;
    smallImage.clipsToBounds = YES;
    label.text  = @"雨点点";
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    [imageView addSubview:label];
    [imageView addSubview:smallImage];
    //[self startAnimation];
    
    UITapGestureRecognizer *geu = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(animation)];
    [imageView addGestureRecognizer:geu];
    imageView.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *geud = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(startAnimation)];
    [smallImage addGestureRecognizer:geud];
    smallImage.userInteractionEnabled = YES;
    
//    [UIView beginAnimations:@"123" context:nil];
//    [UIView setAnimationDuration:3.0f];
//    [UIView setAnimationDelegate:self];
//    [UIView setAnimationDidStopSelector:@selector(kartoon)];
//    smallImage.transform = CGAffineTransformMakeRotation((180.0f*M_PI ) / 180.0f);
//    [UIView commitAnimations];
//    [UIView animateWithDuration:3 animations:^{
//        
//        //
//    }];
//
    
    
//    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(kartoon) userInfo:nil repeats:YES];
    
    
}

- (void) animation {
    
    UIImageView *smallImage = (id)[self.view viewWithTag:300];
    if (smallImage.alpha == 0) {
        
            [UIView animateWithDuration:2 animations:^{
                smallImage.alpha = 1;
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:2 animations:^{
                CGAffineTransform t = CGAffineTransformMakeScale(1.0, 1.0);
                t = CGAffineTransformRotate(t, 0);
                smallImage.transform = t;
                    }];
            }];
    
    }
    
   // NSLog(@"123");
}

- (void) startAnimation {
    UIImageView *smallImage = (id)[self.view viewWithTag:300];
    [UIView animateWithDuration:2 animations:^{
        CGAffineTransform t = CGAffineTransformMakeScale(0.5, 0.5);
        t = CGAffineTransformRotate(t, M_PI);
        smallImage.transform = t;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:1 animations:^{
            smallImage.alpha = 0;
        }];
    }];
}

//-(void) startAnimation
//{
//    UIImageView *smallImage = (id)[self.view viewWithTag:300];
//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationDuration:0.1];
//    [UIView setAnimationDelegate:self];
//    [UIView setAnimationDidStopSelector:@selector(endAnimation)];
//   smallImage.transform = CGAffineTransformMakeRotation(angle * (M_PI / 180.0f));
//    [UIView commitAnimations];
//}

//-(void)endAnimation
//{
//    angle += 10;
//    [self startAnimation];
//}

//- (void) kartoon {
//    UIImageView *smallImage = (id)[self.view viewWithTag:300];
//   // smallImage.frame = CGRectMake(0, 0, 50, 50);
//    
//  //  [UIView setAnimationDidStopSelector:@selector(kartoon)];
//    [UIView animateWithDuration:1 animations:^{
//    
//        smallImage.transform = CGAffineTransformMakeRotation((M_PI / 180.f) * angle);
//    }];
//    angle += 10;
//}

- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 10;
}


- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	NSArray *arr = LabelDataArray[section];
	return arr.count;
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return LabelDataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	FirstTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FirstTableViewCell" forIndexPath:indexPath];
	NSString *imageName = imageArray[indexPath.section][indexPath.row];
	NSString *labelName = LabelDataArray [indexPath.section][indexPath.row];
    cell.HeadImageView.frame = CGRectMake(0, 0, 60, 60);
	cell.HeadImageView.image = [UIImage imageNamed:imageName];
	cell.nameLabel.text = labelName;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
//    if (indexPath.section == 0 && indexPath.row==0) {
//        [cell.HeadImageView setImage:[UIImage imageNamed:@"6"]];
//    }
	return cell;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
