//
//  HomeViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#define WHIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height

#import "HomeViewController.h"
#import "HomeTableViewCell1.h"
#import "HomeTableViewCell2.h"
#import "HomeTableViewCell3.h"
#import "HomeTableViewCell4.h"
#import "DetailViewController.h"

@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>   {
	UITableView *_tableView;
	NSArray *arr ;
    UIScrollView *SCView;
    NSTimer *timer;
    UIPageControl *pageControl;
}

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	arr = @[@[@"",@"",@"",@"",@"",@"",],@[],@[],@[]];
	 [self createTableView];
    
    [self customNavigationItem];
    //[[UINavigationBar appearance] setBackIndicatorImage:[UIImage imageNamed:@"daohang"]];
    //[[UINavigationBar appearance] setBackIndicatorTransitionMaskImage:[UIImage imageNamed:@"daohang"]];
    }

- (void) customNavigationItem {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 25, 25);
    [button setBackgroundImage:[UIImage imageNamed:@"WIFI"] forState:UIControlStateNormal];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)createTableView
{
	_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WHIDTH, HEIGHT -54-49) style:UITableViewStylePlain];
	[self.view addSubview:_tableView];
	// 设置UITableView的数据源和代理
	_tableView.dataSource = self;
	_tableView.delegate = self;
	_tableView.showsVerticalScrollIndicator = NO;
    _tableView.contentInset = UIEdgeInsetsMake(180, 0, 0, 0);
    SCView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, -180, WHIDTH, 180)];
    SCView.contentSize = CGSizeMake(WHIDTH * 2, 180);
    SCView.pagingEnabled = YES;
    SCView.showsHorizontalScrollIndicator = NO;
    SCView.delegate = self;
    pageControl = [[UIPageControl alloc] init];
    pageControl.frame = CGRectMake((WHIDTH - 100) / 2 , -30, 100, 30);
    pageControl.numberOfPages = 2;
    pageControl.currentPage = 0;
    pageControl.userInteractionEnabled = NO;
    
    [_tableView addSubview:pageControl];
    
    
    NSArray *imageName = @[@"banner0",@"banner1"];
    
    // 图片的宽
        CGFloat imageW = SCView.frame.size.width;
    //    CGFloat imageW = 300;
     //    图片高
         CGFloat imageH = SCView.frame.size.height;
    //    图片的Y
         CGFloat imageY = 0;

     //   1.添加2张图片
         for (int i = 0; i < imageName.count; i++) {
                 UIImageView *imageView = [[UIImageView alloc] init];
         //        图片X
                 CGFloat imageX = i * imageW;
         //        设置frame
                 imageView.frame = CGRectMake(imageX, imageY, imageW, imageH);
         //        设置图片
                 //
                 imageView.image = [UIImage imageNamed:imageName[i]];
         //        隐藏指示条
             
                 [SCView addSubview:imageView];
             }
    
    [_tableView addSubview:SCView];
    [self addTimer];
	
	// 注册单元格，通过NIB文件注册单元格
	// 参数1：Nib对象
	// 参数2：复用的标识
	[_tableView registerNib:[UINib nibWithNibName:@"HomeTableViewCell1" bundle:nil] forCellReuseIdentifier:@"HomeTableViewCell1"];
	[_tableView registerNib:[UINib nibWithNibName:@"HomeTableViewCell2" bundle:nil] forCellReuseIdentifier:@"HomeTableViewCell2"];
	[_tableView registerNib:[UINib nibWithNibName:@"HomeTableViewCell3" bundle:nil] forCellReuseIdentifier:@"HomeTableViewCell3"];
	[_tableView registerNib:[UINib nibWithNibName:@"HomeTableViewCell4" bundle:nil] forCellReuseIdentifier:@"HomeTableViewCell4"];
	
	[_tableView bringSubviewToFront:pageControl];
}

- (void) nextImage {
    
    [UIView animateWithDuration:0.2 animations:^{
        NSInteger page = pageControl.currentPage;
        if (page == 1) {
            page = 0;
        }
        else {
            page++;
        }
        CGFloat x = page *WHIDTH;
        SCView.contentOffset = CGPointMake(x, 0);
    }];
    
}
- (void)dealloc {
    if (timer) {
        [timer invalidate];
        timer = nil;
    }
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self addTimer];
}

- (void) addTimer {
    timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(nextImage) userInfo:nil repeats:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [UIView animateWithDuration:0.2 animations:^{
        CGFloat scvW = WHIDTH;
        CGFloat x = SCView.contentOffset.x;
        NSInteger page = (x + scvW / 2) / scvW;
        pageControl.currentPage = page;
    }];
    
    
}

- (void) scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self removeTimer];
}

- (void) removeTimer {
    [timer invalidate];
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
        if (WHIDTH == 375) {
            return 170;
        }
        else if (WHIDTH > 375) {
            return 190;
        }
        else {
            return 150;
        }
		
	}
	else if (indexPath.section == 1) {
        if (WHIDTH == 375) {
            return 140;
        }
        else if (WHIDTH > 375) {
            return 160;
        }
        else {
            return 120;
        }

	}
	else if (indexPath.section == 2) {
		return 380;
	}
	else {
		return 280;
	}
	
}

- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 10;
}


- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//	if (section == 0) {
//		return 1;
//	}
//	else if (section == 1) {
//		return 1;
//	}
//	else if (section == 2){
//		return 1;
//	}
//	else {
//		return 1;
//	}
	return 1;
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 4;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	
	
	
	if (indexPath.section == 0) {
		HomeTableViewCell1 *cell1 = [tableView dequeueReusableCellWithIdentifier:@"HomeTableViewCell1" forIndexPath:indexPath];
		
		
		return cell1;
	}
	else if (indexPath.section == 1) {
		HomeTableViewCell2 *cell2 = [tableView dequeueReusableCellWithIdentifier:@"HomeTableViewCell2" forIndexPath:indexPath];
		
		return cell2;
	}
	else if (indexPath .section == 2) {
		HomeTableViewCell3 *cell3 = [tableView dequeueReusableCellWithIdentifier:@"HomeTableViewCell3" forIndexPath:indexPath];
		
		return cell3;
	}
	else {
		HomeTableViewCell4 *cell4 = [tableView dequeueReusableCellWithIdentifier:@"HomeTableViewCell4" forIndexPath:indexPath];
		
		return cell4;
	}
	
	
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		HomeTableViewCell1 *cell1 = (id)cell;
		cell1.i1.image = [UIImage imageNamed:@"1"];
		cell1.i2.image = [UIImage imageNamed:@"2"];
		cell1.i3.image = [UIImage imageNamed:@"3"];
		cell1.i4.image = [UIImage imageNamed:@"4"];
		cell1.i5.image = [UIImage imageNamed:@"5"];
		cell1.i6.image = [UIImage imageNamed:@"6"];
		cell1.i7.image = [UIImage imageNamed:@"7"];
		cell1.i8.image = [UIImage imageNamed:@"8"];
	}
	else if (indexPath.section == 1) {
		HomeTableViewCell2 *cell2 = (id)cell;
		cell2.i1.image = [UIImage imageNamed:@"组-1"];
		cell2.i2.image = [UIImage imageNamed:@"组-2"];
		cell2.i3.image = [UIImage imageNamed:@"组-3"];
		cell2.i4.image = [UIImage imageNamed:@"ztc"];
		cell2.selectionStyle =  UITableViewCellSelectionStyleNone;
	}
	else if (indexPath.section == 2){
		HomeTableViewCell3 *cell3 = (id)cell;
		cell3.i1.image = [UIImage imageNamed:@"洛带古镇3"];
		cell3.i2.image = [UIImage imageNamed:@"黄龙溪1"];
		cell3.i3.image = [UIImage imageNamed:@"青城山2"];
		cell3.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	else {
		HomeTableViewCell4 *cell4 = (id)cell;
		cell4.bi.image = [UIImage imageNamed:@"洛带"];
		cell4.si.image = [UIImage imageNamed:@"rBACFFOj0smxn-z-AAAfcVSzwdk523_200x200_3"];
		cell4.selectionStyle = UITableViewCellSelectionStyleNone;
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        DetailViewController *vc= [[DetailViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}


@end
