//
//  DetailTableViewCell8.h
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell8 : UITableViewCell

@end
