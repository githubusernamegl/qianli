//
//  ShoppingViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//
#define WHIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height


#import "ShoppingViewController.h"
#import "QGTableViewCell1.h"
#import "QGTableViewCell2.h"
#import "QGTableViewCell3.h"
#import "QGTableViewCell4.h"
#import "QGTableViewCell5.h"

@interface ShoppingViewController () <UITableViewDataSource,UITableViewDelegate> {
    UITableView *myTableView;
    UIPageControl *pageControl;
}

@end

@implementation ShoppingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createTableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) createTableView {
    myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WHIDTH, HEIGHT - 44-49)];
    myTableView.dataSource = self;
    myTableView.delegate = self;
    myTableView.contentInset = UIEdgeInsetsMake(200, 0, 0, 0);
    myTableView.showsVerticalScrollIndicator = NO;
    
    pageControl = [[UIPageControl alloc] init];
    pageControl.frame = CGRectMake((WHIDTH - 100) / 2 , -30, 100, 30);
    pageControl.numberOfPages = 3;
    pageControl.currentPage = 0;
    pageControl.userInteractionEnabled = NO;
    
    [myTableView addSubview:pageControl];
    
    
    UIImageView *imageView =[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"zongzi"]];
    imageView.frame = CGRectMake(0, -200, WHIDTH, 200);
    [myTableView addSubview:imageView];
    for (int i = 1; i <= 3; i++) {
 //       UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:nil]];
    }
    
    [self.view addSubview:myTableView];
    
    for (int i = 1; i <= 5; i++) {
        NSString *str = [NSString stringWithFormat:@"QGTableViewCell%d",i];
        [myTableView registerNib:[UINib nibWithNibName:str bundle:nil] forCellReuseIdentifier:str];
    }

    [myTableView bringSubviewToFront:pageControl];
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (WHIDTH >= 375) {
            return 190;
        }
        else {
            return 170;
        }
        
    }
    else if (indexPath.section == 1) {
        if (WHIDTH <= 375) {
            return 130;
        }
        else {
            return 150;
        }
        
    }
    else if (indexPath.section == 2) {
        if (WHIDTH == 375) {
            return 200;
        }
        else if (WHIDTH > 375) {
            return 220;
        }
        else {
        return 160;
        }
    }
    else if (indexPath.section == 3 && indexPath.row ==0) {
        return 44;
    }
    else if (indexPath.section == 4 && indexPath.row == 0) {
        return 44;
    }
    else if (indexPath.section == 5 && indexPath.row == 0) {
        return 44;
    }
    else {
        if (WHIDTH == 375) {
            return 140;
        }
        else if (WHIDTH > 375) {
            return 160;
        }
        else {
            return 100;
        }
        
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 20;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 5 || section == 4) {
        return 2;
        
    }
    else if (section == 3) {
        return 3;
    }
    else {
        return 1;
    }
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 6;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        QGTableViewCell1 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell1" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"sst"];
        cell.i2.image = [UIImage imageNamed:@"KZ"];
        cell.i3.image = [UIImage imageNamed:@"piao"];
        cell.i4.image = [UIImage imageNamed:@"cz"];
        cell.i5.image = [UIImage imageNamed:@"lw"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 1) {
        QGTableViewCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell2" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"zt1"];
        cell.i2.image = [UIImage imageNamed:@"zt2"];
        cell.i3.image = [UIImage imageNamed:@"zt3"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if ( indexPath.section == 2) {
        QGTableViewCell3 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell3" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"yuzhou"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 3 && indexPath.row == 0) {
        QGTableViewCell4 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell4" forIndexPath:indexPath];
        cell.l1.text = @"附近团购";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
        
    }
    else if (indexPath.section == 4 && indexPath.row == 0) {
        QGTableViewCell4 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell4" forIndexPath:indexPath];
        cell.l1.text = @"精选商家";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 5 && indexPath.row == 0) {
        QGTableViewCell4 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell4" forIndexPath:indexPath];
        cell.l1.text = @"精选商品";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    else {
        QGTableViewCell5 *cell = [tableView dequeueReusableCellWithIdentifier:@"QGTableViewCell5" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"pg"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
}
@end
