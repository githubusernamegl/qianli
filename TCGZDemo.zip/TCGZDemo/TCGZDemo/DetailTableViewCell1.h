//
//  DetailTableViewCell1.h
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *bigImage;
@property (weak, nonatomic) IBOutlet UIImageView *s1;
@property (weak, nonatomic) IBOutlet UIImageView *s2;
@property (weak, nonatomic) IBOutlet UIImageView *s3;

@end
