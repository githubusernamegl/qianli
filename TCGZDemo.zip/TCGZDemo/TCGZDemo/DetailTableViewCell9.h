//
//  DetailTableViewCell9.h
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell9 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *i1;

@end
