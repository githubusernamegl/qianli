//
//  ListViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import "ListViewController.h"

@interface ListViewController ()<UITableViewDataSource,UITableViewDelegate> {
	UITableView *_tableView;
}

@end

@implementation ListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	self.view.backgroundColor = [UIColor whiteColor];
	//[self createTableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//	// 复用单元格，通过注册方式关联的单元格通过该方法进行单元格的复用时，如果没有找到可以复用的单元格内部将自动创建单元格
//	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
//	
//	return cell;
//}
//
//- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//	return 3;
//}
//
//- (void)createTableView
//{
//	_tableView = [[UITableView alloc] initWithFrame:CGRectMake(100, 100, 300, 550)];
//	[self.view addSubview:_tableView];
//	// 设置UITableView的数据源和代理
//	_tableView.dataSource = self;
//	_tableView.delegate = self;
//	
//	_tableView.rowHeight = 120;
//	
//	// 注册单元格，通过NIB文件注册单元格
//	// 参数1：Nib对象
//	// 参数2：复用的标识
//	
//	
//	
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
