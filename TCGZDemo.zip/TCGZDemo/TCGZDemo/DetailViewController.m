//
//  DetailViewController.m
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//
#define WHIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height
#import "DetailViewController.h"
#import "DetailTableViewCell1.h"
#import "DetailTableViewCell2.h"
#import "DetailTableViewCell3.h"
#import "DetailTableViewCell4.h"
#import "DetailTableViewCell5.h"
#import "DetailTableViewCell6.h"
#import "DetailTableViewCell7.h"
#import "DetailTableViewCell8.h"
#import "DetailTableViewCell9.h"
#import "DetailTableViewCell10.h"

@interface DetailViewController () <UITableViewDelegate,UITableViewDataSource> {
    UITableView *_tableView;
    NSArray *imageNamaArray;
    NSArray *LableTextArray;
}

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.tabBarController.tabBar.hidden = YES;
   // self.title = @"洛带古镇";
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, 30)];
    label.text = @"洛带古镇";
    label.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = label;
    
    [self customBackButton];
    [self createTableView];
}

- (void) customBackButton {
    self.navigationItem.hidesBackButton = YES;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 25, 25);
    [button setBackgroundImage:[UIImage imageNamed:@"fh"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(clickedButton) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
}

- (void) clickedButton {
    self.tabBarController.tabBar.hidden = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) createTableView {
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WHIDTH, HEIGHT-55) ];
    [self.view addSubview:_tableView];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.showsVerticalScrollIndicator = NO;
    //NSMutableArray *array = [NSMutableArray array];
//    [tableView registerNib:[UINib nibWithNibName:@"DetailTableViewCell1" bundle:nil] forCellReuseIdentifier:@"DetailTableViewCell1"];
    for (int i = 1; i <= 10; i++) {
        NSString *str = [NSString stringWithFormat:@"DetailTableViewCell%d",i];
        [_tableView registerNib:[UINib nibWithNibName:str bundle:nil] forCellReuseIdentifier:str];
    }
    
    
    
    _tableView.contentInset = UIEdgeInsetsMake(200, 0, 0, 0);
    
    UIView *view = [[[NSBundle mainBundle] loadNibNamed:@"XXBJ" owner:self options:nil]objectAtIndex:0];
    view.frame = CGRectMake(0, -200, WHIDTH, 200);
    [_tableView addSubview:view];
//    UIImageView *imageView = [[UIImageView alloc] init];
//    imageView.frame = CGRectMake(0, -200, WHIDTH, 200);
//    imageView.image = [UIImage imageNamed:@"bj"];
//    [_tableView addSubview:imageView];
    
}

- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 && indexPath.row == 0) {
        return 280;
    }
    else if (indexPath.section == 0 && indexPath.row == 1) {
        return 80;
    }
    else if (indexPath.section == 1) {
        if (WHIDTH < 375) {
            return 200;
        }
        else {
            return 230;
        }
        
    }
    else if (indexPath.section == 2) {
        return 132;
    }
    else if (indexPath.section == 3 && indexPath.row == 0) {
        return 167;
    }
    else if (indexPath.section == 3 && indexPath.row == 1) {
        return 120;
    }
    else if (indexPath.section == 3 && indexPath.row == 2) {
        return 120;
    }
    else if (indexPath.section == 4 && indexPath.row == 0) {
        return 220;
    }
    else if (indexPath.section == 4 && indexPath.row == 1) {
        return 128;
    }
    else if (indexPath.section == 5) {
        return 140;
    }
    else if (indexPath.section == 6) {
        return 160;
    }
    else {
        return 160;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 2;
    }
    else if (section == 3) {
        return 3;
    }
    else if (section == 4){
        return 2;
    }
    else {
        return 1;
    }
    
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 7;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 && indexPath.row == 0) {
        DetailTableViewCell1 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell1" forIndexPath:indexPath];
        cell.bigImage.image = [UIImage imageNamed:@"youwan"];
        cell.s1.image = [UIImage imageNamed:@"yy"];
        cell.s2.image = [UIImage imageNamed:@"yzb"];
        cell.s3.image = [UIImage imageNamed:@"lx"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 0 && indexPath.row == 1) {
        DetailTableViewCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell2" forIndexPath:indexPath];
        cell.dImage.image = [UIImage imageNamed:@"xnxs"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 1) {
        DetailTableViewCell3 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell3" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"yh"];
        cell.i2.image = [UIImage imageNamed:@"h"];
        cell.i3.image = [UIImage imageNamed:@"cc"];
        cell.i4.image = [UIImage imageNamed:@"dw"];
        cell.i5.image = [UIImage imageNamed:@"dw"];
        cell.i6.image = [UIImage imageNamed:@"dw"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 2) {
        DetailTableViewCell4 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell4" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"tx"];
        cell.i2.image = [UIImage imageNamed:@"tc"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 3 && indexPath.row == 0) {
        DetailTableViewCell5 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell5" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"men"];
        return cell;
    }
    else if (indexPath.section == 3 && indexPath.row == 1) {
        DetailTableViewCell6 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell6" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"hh"];
        cell.l1.text = @"玉带湖";
        cell.l2.text = @"玉带湖，储水量达120万立方米，常年被花与果环绕，环境幽静，空气清新，";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 3 && indexPath.row ==2) {
        DetailTableViewCell6 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell6" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"lou"];
        cell.l1.text = @"燃灯古寺";
        cell.l2.text = @"燃灯寺坐落于成都市龙泉驿区龙泉山脉中段三峨眉山下洛带古镇，西距成都仅18公里。为成都乐郊历史上一大名寺，距今已1400多年，影响...";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 4 && indexPath.row == 0) {
        DetailTableViewCell7 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell7" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"cai"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if ( indexPath.section == 4 && indexPath.row == 1) {
        DetailTableViewCell8 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell8" forIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else if (indexPath.section == 5) {
        DetailTableViewCell9 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell9" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"tx"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    else {
        DetailTableViewCell10 *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailTableViewCell10" forIndexPath:indexPath];
        cell.i1.image = [UIImage imageNamed:@"qiao"];
        cell.i2.image = [UIImage imageNamed:@"talou"];
        cell.i3.image = [UIImage imageNamed:@"denglong"];
        cell.i4.image = [UIImage imageNamed:@"zhonglou"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}

@end
