//
//  DetailTableViewCell2.h
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *dImage;

@end
