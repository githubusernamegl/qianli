//
//  FQTableViewCell.h
//  TFGZ
//
//  Created by Higgses on 16/5/6.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FQTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *bigImage;
@property (weak, nonatomic) IBOutlet UIImageView *smallImage;

@end
