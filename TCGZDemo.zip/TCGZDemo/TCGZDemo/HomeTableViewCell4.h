//
//  HomeTableViewCell4.h
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell4 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *bi;
@property (weak, nonatomic) IBOutlet UIImageView *si;

@end
