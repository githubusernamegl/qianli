//
//  FQViewController.m
//  TFGZ
//
//  Created by joe@chanlytech on 16/5/4.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//
#define WHIDTH self.view.bounds.size.width
#define HEIGHT self.view.bounds.size.height
#import "FQViewController.h"
#import "SQCollectionViewCell.h"
#import "FQTableViewCell.h"

@interface FQViewController () <UITableViewDelegate,UITableViewDataSource,UICollectionViewDataSource,UICollectionViewDelegate,UIScrollViewDelegate> {
    UITableView *myTableView;
    UIScrollView *SCView;
    UICollectionView *_tableView;
    UIView *view;
    BOOL *isRight;
}

@end

@implementation FQViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIButton *label1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, WHIDTH / 2, 30)];
    [self.view addSubview:label1];
    [label1 setTitle:@"游记" forState:UIControlStateNormal];
    [label1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    //label1.textAlignment = NSTextAlignmentCenter;
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 35, WHIDTH / 2, 3)];
   // view.backgroundColor = [UIColor redColor];
    view.backgroundColor = [UIColor colorWithRed:89/255.0 green:189/255.0 blue:188/255.0 alpha:1];
    [self.view addSubview:view];
//    UIGestureRecognizer *geu = [[UIGestureRecognizer alloc] initWithTarget:self action:@selector(label1)];
//    [label1 addGestureRecognizer:geu];
    //label1.userInteractionEnabled = YES;
    [label1 addTarget:self action:@selector(label1) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *label2 = [[UIButton alloc] initWithFrame:CGRectMake(WHIDTH / 2, 0, WHIDTH / 2, 30)];
    [self.view addSubview:label2];
    [label2 setTitle:@"社区" forState:UIControlStateNormal];
    [label2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [label2 addTarget:self action:@selector(label2) forControlEvents:UIControlEventTouchUpInside];
    
    SCView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 35, WHIDTH, HEIGHT -148)];
   // SCView.backgroundColor = [UIColor redColor];
    SCView.pagingEnabled = YES;
    SCView.showsVerticalScrollIndicator = NO;
    SCView.showsHorizontalScrollIndicator = NO;
    SCView.contentSize = CGSizeMake(WHIDTH * 2, 0);
    SCView.bounces = NO;
    SCView.delegate = self;
    
    [self.view addSubview:SCView];
    
    [self customNavigationItem];
    [self createTableView];
}

- (void) label1 {
    
    
      //  if (view.frame.origin.x > WHIDTH / 2) {
            [UIView animateWithDuration:0.5 animations:^{
                CGRect rect;
                rect = view.frame;
                CGRect rect2 = rect;
                rect.origin.x -= WHIDTH / 2;
                view.frame = rect;
                SCView.contentOffset = CGPointMake(0 , 0);
                if (rect.origin.x < 0) {
                    view.frame = rect2;
                }
            }];
     //   }
    
    
   // NSLog(@"123");
}

- (void) label2 {
    //if (view.frame.origin.x < WHIDTH / 2) {
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect;
            rect = view.frame;
            CGRect rect2 = rect;
            rect.origin.x += WHIDTH / 2;
            view.frame = rect;
            SCView.contentOffset = CGPointMake(WHIDTH , 0);
            if (rect.origin.x >= WHIDTH ) {
                view.frame = rect2;
            }
        }];
   // }
    
    
}

//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
//    CGRect rect = view.frame;
//    rect.origin.x = WHIDTH / 2 +rect.origin.x;
//    view.frame = rect;
//}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    
    if (velocity.x>0) {
        if (view.frame.origin.x <= WHIDTH / + view.frame.origin.x) {
            [UIView animateWithDuration:0.5 animations:^{
                CGRect rect;
                rect = view.frame;
                rect.origin.x += WHIDTH / 2;
                view.frame = rect;
            }];
        }
        
        
    }
    if (velocity.x<0) {
        if (view.frame.origin.x > 0) {
            [UIView animateWithDuration:0.5 animations:^{
                CGRect rect;
                rect = view.frame;
                rect.origin.x -= WHIDTH / 2;
                
                view.frame = rect;
            }];
        }
        
        
    }
    if (velocity.x==0) {
        
        [UIView animateWithDuration:0.5 animations:^{
            CGRect rect;
            rect = view.frame;
            
            view.frame = rect;
        }];
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) customNavigationItem {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 25, 25);
    [button setBackgroundImage:[UIImage imageNamed:@"xie"] forState:UIControlStateNormal];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, 0, 25, 25);
    [button1 setBackgroundImage:[UIImage imageNamed:@"ss"] forState:UIControlStateNormal];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button1];
}

- (void) createTableView {
    myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 13, WHIDTH, HEIGHT- 150)];
    myTableView.dataSource = self;
    myTableView.delegate = self;
    myTableView.showsVerticalScrollIndicator = NO;
    if (WHIDTH <= 375) {
        myTableView.rowHeight = 190;
        
    }
    else {
        myTableView.rowHeight = 210;
    }
    [myTableView registerNib:[UINib nibWithNibName:@"FQTableViewCell" bundle:nil] forCellReuseIdentifier:@"FQTableViewCell"];
    [SCView addSubview:myTableView];
    
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    _tableView = [[UICollectionView alloc] initWithFrame:CGRectMake(WHIDTH, 13, WHIDTH, HEIGHT - 160) collectionViewLayout:layout];
    _tableView.backgroundColor = [UIColor colorWithRed:220 / 255.0 green:220 / 255.0 blue:216 / 255.0 alpha:1];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.showsVerticalScrollIndicator = NO;
    layout.itemSize = CGSizeMake(140, 70);
    layout.minimumLineSpacing = 10;
    layout.minimumInteritemSpacing = 10;
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    [_tableView registerNib:[UINib nibWithNibName:@"SQCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"SQCollectionViewCell"];
    [SCView addSubview:_tableView];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FQTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FQTableViewCell" forIndexPath:indexPath];
    cell.bigImage.image = [UIImage imageNamed:@"fqbj"];
    cell.smallImage.image = [UIImage imageNamed:@"tx"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SQCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SQCollectionViewCell" forIndexPath:indexPath];
    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 20;
}

@end
