//
//  DetailTableViewCell6.h
//  TFGZ
//
//  Created by Higgses on 16/5/5.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewCell6 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *i1;
@property (weak, nonatomic) IBOutlet UILabel *l1;
@property (weak, nonatomic) IBOutlet UILabel *l2;

@end
