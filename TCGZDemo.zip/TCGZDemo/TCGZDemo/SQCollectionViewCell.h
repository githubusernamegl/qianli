//
//  SQCollectionViewCell.h
//  TFGZ
//
//  Created by Higgses on 16/5/9.
//  Copyright © 2016年 ChanlyTech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQCollectionViewCell : UICollectionViewCell

@end
