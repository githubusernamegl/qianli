//
//  MyTabBar.m
//  TAB
//
//  Created by Higgses on 16/5/23.
//  Copyright © 2016年 ChanlyTech inc. All rights reserved.
//

#import "MyTabBar.h"

@implementation MyTabBar 



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (id)initWithFrame:(CGRect)frame {
//    NSArray *normolImage = @[@"sy@2x.png",@"zp@2x.png",@"gw@2x.png",@"js@2x.png",@"gr@2x.png"];
//    NSArray *selectedImage = @[@"sys@2x.png",@"zps@2x.png",@"gws@2x.png",@"jss@2x.png",@"grs@2x.png"];
    self = [super initWithFrame:frame];
    if (self) {
        for (int i = 0; i < 5; i++) {
            UIButton *button = [[UIButton alloc] init];
//            [button setBackgroundImage:[UIImage imageNamed:normolImage[i]] forState:UIControlStateNormal];
//            [button setBackgroundImage:[UIImage imageNamed:selectedImage[i]] forState:UIControlStateSelected];
            [button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
//            button.frame.size.width == button.currentImage.size.width;
//            button.frame.size.height == button.currentImage.size.height;
           // button.backgroundColor = [UIColor whiteColor];
            [self addSubview:button];
            self.plusBtn = button;
            
        }
    }
    return self;
}

- (void) buttonClick {
    if ([self.tabBarDelegate respondsToSelector:@selector(tabBarDidClickPlusButton:)]) {
        [self.tabBarDelegate tabBarDidClickPlusButton:self];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
  //  CGFloat tabbarButtonWidth = self.frame.size.width / 5;
    CGFloat tabbarButtonIndex = 0;
    for (UIView *child in self.subviews) {
        Class class = NSClassFromString(@"UITabBarButton");
        if ([child isKindOfClass:class]) {
//            child.frame.size.width == tabbarButtonWidth;
//            child.frame.origin.x == tabbarButtonIndex *tabbarButtonWidth;
            tabbarButtonIndex++;
        }
    }
}

@end
