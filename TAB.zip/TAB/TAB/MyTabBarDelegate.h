//
//  MyTabBarDelegate.h
//  TAB
//
//  Created by Higgses on 16/5/23.
//  Copyright © 2016年 ChanlyTech inc. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MyTabBar;
@protocol MyTabBarDelegate <UITabBarDelegate>

@optional
- (void)tabBarDidClickPlusButton:(MyTabBar *)tabBar;

@end
