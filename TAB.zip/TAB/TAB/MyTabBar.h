//
//  MyTabBar.h
//  TAB
//
//  Created by Higgses on 16/5/23.
//  Copyright © 2016年 ChanlyTech inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTabBarDelegate.h"

@interface MyTabBar : UITabBar



@property (nonatomic,weak) UIButton *plusBtn;
@property (nonatomic, weak) id<MyTabBarDelegate> tabBarDelegate;

@end
