//
//  MyTabBarController.m
//  TAB
//
//  Created by Higgses on 16/5/23.
//  Copyright © 2016年 ChanlyTech inc. All rights reserved.
//

#import "MyTabBarController.h"
#import "MyTabBar.h"
#import "OneViewController.h"
#import "TwoViewController.h"
#import "ThreeViewController.h"
#import "FourViewController.h"
#import "FiveViewController.h"

@interface MyTabBarController ()<MyTabBarDelegate> {
    NSMutableArray *array;
}

@end

@implementation MyTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    array = [NSMutableArray array];
    MyTabBar *myTabBar = [[MyTabBar alloc] initWithFrame:self.tabBar.frame];
    myTabBar.tabBarDelegate = self;
    [self setValue:myTabBar forKey:@"tabBar"];
    OneViewController *one = [[OneViewController alloc]init];
    one.view.backgroundColor = [UIColor purpleColor];
    [self addChildController:one title:@"首页" image:@"sy@2x.png" selectedImage:@"sys@2x.png"];
    TwoViewController *two = [[TwoViewController alloc] init];
    two.view.backgroundColor = [UIColor redColor];
    [self addChildController:two title:@"风情" image:@"zp@2x.png" selectedImage:@"zps@2x.png"];
    ThreeViewController *three = [[ThreeViewController alloc] init];
    three.view.backgroundColor = [UIColor greenColor];
    [self addChildController:three title:@"趣购" image:@"gw@2x.png" selectedImage:@"gws@2x.png"];
    FourViewController *four = [[FourViewController alloc] init];
    four.view.backgroundColor = [UIColor yellowColor];
    [self addChildController:four title:@"民生" image:@"js@2x.png" selectedImage:@"jss@2x.png"];
    FiveViewController *five = [[FiveViewController alloc] init];
    [self addChildController:five title:@"个人" image:@"gr.png" selectedImage:@"grs@2x.png"];
    five.view.backgroundColor = [UIColor cyanColor];
    myTabBar.translucent = NO;
    myTabBar.backgroundImage = [UIImage imageNamed:@"daohang"];
    myTabBar.tintColor = [UIColor whiteColor];
    //self.viewControllers = @[one,two,three,four,five];
    
}

- (void)tabBarDidClickPlusButton:(MyTabBar *)tabBar {
    
}

- (void) addChildController:(UIViewController *) childViewController title:(NSString *) title image:(NSString *) image selectedImage:(NSString *) selectedImage{
    childViewController.title = title;
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
    label.text = title;
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    childViewController.navigationItem.titleView = label;
    
    
    childViewController.tabBarItem.image = [[UIImage imageNamed:image]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    childViewController.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:childViewController];
    [self addChildViewController:nav];
    [nav.navigationBar setBackgroundImage:[UIImage imageNamed:@"daohang1"] forBarMetrics:UIBarMetricsDefault];
    [array addObject:nav];
    self.viewControllers = array;
    UIColor *titleHighlightedColor = [UIColor whiteColor];
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                       titleHighlightedColor, UITextAttributeTextColor,
                                                       nil] forState:UIControlStateSelected];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
